<div id='footer'>
    © 2016 HostKeep Property Management Pty. Ltd. All rights reserved.<br />
    ABN: 20 606 153 646
</div>
