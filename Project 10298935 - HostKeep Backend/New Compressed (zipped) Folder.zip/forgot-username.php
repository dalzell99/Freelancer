<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Forgotten Username</title>

        <?php include('head.php'); ?>
    </head>
    <body>
        <div class='.container-fluid'>
            <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">
                <header>
                    <?php include('header.php'); ?>
                </header>

                <main>
                    <p>
                        COMING SOON
                    </p>

                    <table>
                        <tr>
                            <td>
                                <!-- Empty -->
                            </td>
                            <td>
                                <!-- Empty -->
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <!-- Empty -->
                            </td>
                            <td>
                                <!-- Empty -->
                            </td>
                        </tr>

                        <tr>
                            <td>
                                <!-- Empty -->
                            </td>
                            <td>
                                <!-- Empty -->
                            </td>
                        </tr>
                    </table>
                </main>

                <footer>
                    <?php include('footer.php'); ?>
                </footer>
            </div>
        </div>
    </body>
</html>
