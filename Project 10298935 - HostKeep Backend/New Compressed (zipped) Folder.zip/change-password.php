<table>
    <tr>
        <td>
            Current Password
        </td>
        <td>
            <input type="password" id="changepasswordCurrentPassword">
        </td>
        <td>
            <i id='changepasswordCurrentPasswordCheck' class="fa fa-check fa-15x" aria-hidden="true"></i>
            <i id='changepasswordCurrentPasswordCross' class="fa fa-times fa-15x" aria-hidden="true"></i>
        </td>
    </tr>
    <tr>
        <td>
            New Password
        </td>
        <td>
            <input type="password" id="changepasswordNewPassword">
        </td>
    </tr>
    <tr>
        <td>
            Confirm New Password
        </td>
        <td>
            <input type="password" id="changepasswordConfirmPassword">
        </td>
        <td>
            <i id='changepasswordConfirmPasswordCheck' class="fa fa-check fa-15x" aria-hidden="true"></i>
            <i id='changepasswordConfirmPasswordCross' class="fa fa-times fa-15x" aria-hidden="true"></i>
        </td>
    </tr>
</table>

<button id='changepasswordButton'>Save Password</button>
