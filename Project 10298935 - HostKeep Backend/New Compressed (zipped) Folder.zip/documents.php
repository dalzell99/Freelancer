<table>
    <tr>
        <th>
            Report
        </th>
        <th>
            Property
        </th>
        <th>
            Month
        </th>
        <th>
            Date Uploaded
        </th>
        <th>
            Notes
        </th>
    </tr>
    <tr>
        <td>
            Report Name 1
        </td>
        <td>
            Property 1
        </td>
        <td>
            April
        </td>
        <td>
            Mon 25th April 2016
        </td>
        <td>
            B-sharp, A-minor
        </td>
    </tr>
    <tr>
        <td>
            Report Name 2
        </td>
        <td>
            Property 2
        </td>
        <td>
            April
        </td>
        <td>
            Mon 25th April 2016
        </td>
        <td>
            B-sharp, A-minor
        </td>
    </tr>
</table>
