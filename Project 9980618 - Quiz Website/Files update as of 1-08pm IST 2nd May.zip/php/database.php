<?php
$dbusername = 'ccrsc638_test';
$dbpassword = 'freelancer9808082';
$dbname = 'ccrsc638_9980618';
$databasephpPrizeEmail = 'rewards@quizeto.com';
$databasephpNoReplyEmail = 'noreply@quizeto.com';
$databasephpQueryEmail = 'query@quizeto.com';
$databasephpInfoEmail = 'info@quizeto.com';
$databasephpWithdrawalEmail = 'redeem@quizeto.com';
$salt = '$&%&^sf65g41fg65fds1GSGDvbedghGGRGSDGDGsdY^#(*&#^*&^f1gf';
$minRegisteredUsers = 10;
?>
