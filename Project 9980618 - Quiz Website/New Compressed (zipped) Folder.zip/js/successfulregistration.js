window.onload = function() {
    global();
    
    $('li.active').removeClass('active');
}