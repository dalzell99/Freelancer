<?php
$dbusername = 'quizetoc_admin';
$dbpassword = 'falcon@123';
$dbname = 'quizetoc_quizeto';
$databasephpPrizeEmail = 'rewards@quizeto.com';
$databasephpNoReplyEmail = 'noreply@quizeto.com';
$databasephpQueryEmail = 'query@quizeto.com';
$databasephpInfoEmail = 'info@quizeto.com';
$databasephpWithdrawalEmail = 'redeem@quizeto.com';
$salt = '$&%&^sf65g41fg65fds1GSGDvbedghGGRGSDGDGsdY^#(*&#^*&^f1gf';
?>
