<?php
$dbusername = 'quizetoc_admin';
$dbpassword = 'falcon@123';
$dbname = 'quizetoc_quizeto';
$databasephpPrizeEmail = 'rewards@iqzeto.com';
$databasephpNoReplyEmail = 'noreply@iqzeto.com';
$databasephpQueryEmail = 'query@iqzeto.com';
$databasephpInfoEmail = 'info@iqzeto.com';
$databasephpWithdrawalEmail = 'redeem@iqzeto.com';
$salt = '$&%&^sf65g41fg65fds1GSGDvbedghGGRGSDGDGsdY^#(*&#^*&^f1gf';
?>
