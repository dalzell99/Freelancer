<?php
$dbusername = 'ccrsc638_test';
$dbpassword = 'freelancer9808082';
$dbname = 'ccrsc638_9952856';
?>